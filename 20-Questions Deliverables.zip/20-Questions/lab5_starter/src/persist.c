#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "lab5.h"

extern Node *g_root;

#define MAGIC 0x41544C35  /* "ATL5" */
#define VERSION 1

typedef struct {
    Node *node;
    int id;
} NodeMapping;

/* TODO 27: Implement save_tree
 * Save the tree to a binary file using BFS traversal
 * 
 * Binary format:
 * - Header: magic (4 bytes), version (4 bytes), nodeCount (4 bytes)
 * - For each node in BFS order:
 *   - isQuestion (1 byte)
 *   - textLen (4 bytes)
 *   - text (textLen bytes, no null terminator)
 *   - yesId (4 bytes, -1 if NULL)
 *   - noId (4 bytes, -1 if NULL)
 * 
 * Steps:
 * 1. Return 0 if g_root is NULL
 * 2. Open file for writing binary ("wb")
 * 3. Initialize queue and NodeMapping array
 * 4. Use BFS to assign IDs to all nodes:
 *    - Enqueue root with id=0
 *    - Store mapping[0] = {g_root, 0}
 *    - While queue not empty:
 *      - Dequeue node and id
 *      - If node has yes child: add to mappings, enqueue with new id
 *      - If node has no child: add to mappings, enqueue with new id
 * 5. Write header (magic, version, nodeCount)
 * 6. For each node in mapping order:
 *    - Write isQuestion, textLen, text bytes
 *    - Find yes child's id in mappings (or -1)
 *    - Find no child's id in mappings (or -1)
 *    - Write yesId, noId
 * 7. Clean up and return 1 on success
 */
 
//Function used in save_tree
//Linear search through mapping array (mapping is size count)
//Finds the numeric id for node 'n' previously recorded in mapping[]
static int32_t find_id(NodeMapping *mapping, int count, Node *n) {
    for (int i = 0; i < count; i++) {
      if (mapping[i].node == n) {
        return mapping[i].id;
        }
      }
    return -1;
}
 
int save_tree(const char *filename) {
    // TODO: Implement this function -- DONE
    // This is complex - break it into smaller steps
    // You'll need to use the Queue functions you implemented
    //1. 
    //Return 0 if g_root is NULL
    if (g_root == NULL) {
    return 0;
    }
    //3. 
    //Initialize queue and NodeMapping array
    int capacity = 64;
    int count = 0;
    NodeMapping *mapping = malloc(sizeof(NodeMapping) * capacity);
    
    if (!mapping) {
    return 0;
    }
    //Store mapping[0] = {g_root, 0}
    mapping[count].node = g_root;
    //Enqueue root with id=0
    mapping[count].id = 0;
    count++;
    //4. 
    //Use BFS to assign IDs to all nodes:
    //For each mapping entry: examine, if not already recorded, add yes/no children
    for (int head = 0; head < count; head++) {
    //While queue not empty:
    //Dequeue node and id
      Node *curr = mapping[head].node;
      
      //YES child
      if (curr->yes) {
        int found = 0;
        for (int j = 0; j < count; j++) {
          if (mapping[j].node == curr->yes) {
            found = 1; //Already discovered; skip
            break;
            }
          }
        if (!found) {
          if (count >= capacity) {
            capacity *= 2;
            NodeMapping *tmp = realloc(mapping, sizeof(NodeMapping) * capacity);
            
            if (!tmp) {
              free(mapping);
              return 0;
              }
              
            mapping = tmp;
            }
          //If node has yes child: add to mappings, enqueue with new id
          mapping[count].node = curr->yes;
          mapping[count].id = count;
          count++;
          }
        }
        
        //NO child
        if (curr->no) {
          int found = 0;
          for (int j = 0; j < count; j++) {
            if (mapping[j].node == curr->no) {
              found = 1; //Already discovered; skip
              break;
              }
            }
          if (!found) {
            if (count >= capacity) {
              capacity *= 2;
              NodeMapping *tmp = realloc(mapping, sizeof(NodeMapping) * capacity);
              
              if (!tmp) {
              free(mapping);
              return 0;
              }
              
            mapping = tmp;
            }
          //If node has no child: add to mappings, enqueue with new id    
          mapping[count].node = curr->no;
          mapping[count].id = count;
          count++;
          }
        }
      }
      //2. 
      //Open file for writing binary ("wb")
      FILE *f = fopen(filename, "wb");
      
      if (!f) {
      free(mapping);
      return 0;
      }
      //5. 
      //Write header (magic, version, nodeCount)
      uint32_t magic = MAGIC;
      uint32_t version = VERSION;
      uint32_t nodeCount = (uint32_t)count;
      if (fwrite(&magic, sizeof(magic), 1, f) != 1) {
        goto save_error;
        }
      if (fwrite(&version, sizeof(version), 1, f) != 1) {
        goto save_error;
      }
      if (fwrite(&nodeCount, sizeof(nodeCount), 1, f) != 1) {
        goto save_error;
      }
        //6. 
        //For each node in mapping order:  
        for (int i = 0; i < count; i++) {
          Node *n = mapping[i].node;
          //Write isQuestion, textLen, text bytes
          uint8_t isQ = (uint8_t)(n->isQuestion ? 1 : 0);
          if (fwrite(&isQ, sizeof(isQ), 1, f) != 1) {
          goto save_error;
          }
        
        uint32_t textLen = (n->text != NULL) ? (uint32_t)strlen(n->text) : 0;
        if (fwrite(&textLen, sizeof(textLen), 1, f) != 1) {
        goto save_error;
        }
        if (textLen > 0) {
          if (fwrite(n->text, 1, textLen, f) != textLen) {
          goto save_error;
          }
        }
        //Find yes child's id in mappings (or -1)
        int32_t yesId = (n->yes) ? find_id(mapping, count, n->yes) : -1;
        //Find no child's id in mappings (or -1)
        int32_t noId = (n->no) ? find_id(mapping, count, n->no) : -1;
        
        //Write yesId, noId
        if (fwrite(&yesId, sizeof(yesId), 1, f) != 1) {
          goto save_error;
          }
        if (fwrite(&noId, sizeof(noId), 1, f) != 1) {
          goto save_error;
          }
        }
        //7. 
        //Clean up and return 1 on success
        fclose(f);
        free(mapping);
        return 1;
        
      save_error:
        if (f) {
          fclose(f);
          }
        free(mapping);
        return 0;
        
}

/* TODO 28: Implement load_tree
 * Load a tree from a binary file and reconstruct the structure
 * 
 * Steps:
 * 1. Open file for reading binary ("rb")
 * 2. Read and validate header (magic, version, count)
 * 3. Allocate arrays for nodes and child IDs:
 *    - Node **nodes = calloc(count, sizeof(Node*))
 *    - int32_t *yesIds = calloc(count, sizeof(int32_t))
 *    - int32_t *noIds = calloc(count, sizeof(int32_t))
 * 4. Read each node:
 *    - Read isQuestion, textLen
 *    - Validate textLen (e.g., < 10000)
 *    - Allocate and read text string (add null terminator!)
 *    - Read yesId, noId
 *    - Validate IDs are in range [-1, count)
 *    - Create Node and store in nodes[i]
 * 5. Link nodes using stored IDs:
 *    - For each node i:
 *      - If yesIds[i] >= 0: nodes[i]->yes = nodes[yesIds[i]]
 *      - If noIds[i] >= 0: nodes[i]->no = nodes[noIds[i]]
 * 6. Free old g_root if not NULL
 * 7. Set g_root = nodes[0]
 * 8. Clean up temporary arrays
 * 9. Return 1 on success
 * 
 * Error handling:
 * - If any read fails or validation fails, goto load_error
 * - In load_error: free all allocated memory and return 0
 */
int load_tree(const char *filename) {
    // TODO: Implement this function -- DONE
    // This is the most complex function in the lab
    // Take it step by step and test incrementally
    //1.  
    //Open file for reading binary ("rb")
    FILE *f = fopen(filename, "rb");
      if (!f) {
        return 0;
        }
    //2.
    //Read and validate header (magic, version, count)
    uint32_t magic = 0;
    uint32_t version = 0;
    uint32_t count = 0;
    
    if (fread(&magic, sizeof(magic), 1, f) != 1) {
      goto load_error;
      }
    if (fread(&version, sizeof(version), 1, f) != 1) {
      goto load_error;
      }
    if (fread(&count, sizeof(count), 1, f) != 1) {
      goto load_error;
      }
    
    if (magic != MAGIC || version != VERSION) {
      goto load_error;
      }
    
    if (count == 0) {
      goto load_error;
      }
    //3.
    //Allocate arrays for nodes and child IDs:
    Node **nodes = calloc(count, sizeof(Node*));
    int32_t *yesIds = calloc(count, sizeof(int32_t));
    int32_t *noIds = calloc(count, sizeof(int32_t));
    
    if (!nodes || !yesIds || !noIds) {
      goto load_error;
    }
    //4.
    //Read each node:
    for (uint32_t i = 0; i < count; i++) {
      uint8_t isQ = 0;
      uint32_t textLen = 0;
      //Read isQuestion, textLen
      if (fread(&isQ, sizeof(isQ), 1, f) != 1) {
        goto load_error;
        }
      if (fread(&textLen, sizeof(textLen), 1, f) != 1) {
        goto load_error;
        }
      //Validate textLen (e.g., < 10000)
      if (textLen > 10000) {
        goto load_error;
        }
      
      char *text = NULL;
      if (textLen > 0) {
      //(add null terminator!)
        text = malloc(textLen + 1);
        if (!text) {
          goto load_error;
          }
          //Allocate and read text string (add null terminator!)
        if (fread(text, 1, textLen, f) != textLen) {
          free(text);
          goto load_error;
          }
        text[textLen] = '\0';
        } else {
          text = strdup("");
          if (!text) {
            goto load_error;
            }
          }
          //Read yesId, noId
          int32_t yid = -1, nid = -1; //yid = yesId and nid = noId
          if (fread(&yid, sizeof(yid), 1, f) != 1) {
            free(text);
            goto load_error;
            }
          if (fread(&nid, sizeof(nid), 1, f) != 1) {
            free(text);
            goto load_error;
            }
          //Validate IDs are in range [-1, count)
          if (!((yid >= -1 && yid < (int32_t)count) && (nid >= -1 && nid < (int32_t)count))) {
            free(text);
            goto load_error;
            }
          //Create Node and store in nodes[i]
          Node *node = malloc(sizeof(Node));
          if (!node) {
            free(text);
            goto load_error;
            }
          node->text = text;
          node->isQuestion = (isQ != 0) ? 1 : 0;
          node->yes = node->no = NULL;
          
          nodes[i] = node;
          yesIds[i] = yid;
          noIds[i] = nid;
          }
        //5. 
        //Link nodes using stored IDs:
        //For each node i:
        for (uint32_t i = 0; i < count; i++) {
          if (yesIds[i] >= 0) {
            nodes[i]->yes = nodes[ yesIds[i] ];
            }
          if (noIds[i] >= 0) {
            nodes[i]->no = nodes[ noIds[i] ];
            }
          }
        //6.
        //Free old g_root if not NULL
        if (g_root != NULL) {
          free_tree(g_root);
          }
        //7.
        g_root = nodes[0];
        //8.
        //Clean up temporary arrays
        free(nodes);
        free(yesIds);
        free(noIds);
        fclose(f);
        //9.
        //Return 1 on success
        return 1;
        
        //Error handling:
        //If any read fails or validation fails, goto load_error
      load_error:
        if (f) {
          fclose(f);
          }
          //In load_error: free all allocated memory and return 0
        if (nodes) {
          for (uint32_t i = 0; i < count; i++) {
            if (nodes[i]) {
              if (nodes[i]->text) {
                free(nodes[i]->text);
                }
              free(nodes[i]);
              }
            }
          free(nodes);
          }
        if (yesIds) {
          free(yesIds);
          }
        if (noIds) {
          free(noIds);
          }
      
      return 0;   
        
}
