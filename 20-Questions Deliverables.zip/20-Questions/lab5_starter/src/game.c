#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include "lab5.h"

extern Node *g_root;
extern EditStack g_undo;
extern EditStack g_redo;
extern Hash g_index;

/* TODO 31: Implement play_game
 * Main game loop using iterative traversal with a stack
 * 
 * Key requirements:
 * - Use FrameStack (NO recursion!)
 * - Push frames for each decision point
 * - Track parent and answer for learning
 * 
 * Steps:
 * 1. Initialize and display game UI
 * 2. Initialize FrameStack
 * 3. Push root frame with answeredYes = -1
 * 4. Set parent = NULL, parentAnswer = -1
 * 5. While stack not empty:
 *    a. Pop current frame
 *    b. If current node is a question:
 *       - Display question and get user's answer (y/n)
 *       - Set parent = current node
 *       - Set parentAnswer = answer
 *       - Push appropriate child (yes or no) onto stack
 *    c. If current node is a leaf (animal):
 *       - Ask "Is it a [animal]?"
 *       - If correct: celebrate and break
 *       - If wrong: LEARNING PHASE
 *         i. Get correct animal name from user
 *         ii. Get distinguishing question
 *         iii. Get answer for new animal (y/n for the question)
 *         iv. Create new question node and new animal node
 *         v. Link them: if newAnswer is yes, newQuestion->yes = newAnimal
 *         vi. Update parent pointer (or g_root if parent is NULL)
 *         vii. Create Edit record and push to g_undo
 *         viii. Clear g_redo stack
 *         ix. Update g_index with canonicalized question
 * 6. Free stack
 */
void play_game() {
    //1.
    //Initialize and display game UI
    clear();
    attron(COLOR_PAIR(5) | A_BOLD);
    mvprintw(0, 0, "%-80s", " Playing 20 Questions");
    attroff(COLOR_PAIR(5) | A_BOLD);
    
    mvprintw(2, 2, "Think of an animal, and I'll try to guess it!");
    mvprintw(3, 2, "Press any key to start...");
    refresh();
    getch();
    
    // TODO: Implement the game loop
    // Initialize FrameStack
    // Push root
    // Loop until stack empty or guess is correct
    // Handle question nodes and leaf nodes differently
    //2.
    //Initialize FrameStack
    FrameStack stack;
    fs_init(&stack);
    
    // TODO: Your implementation here -- DONE (I think; no test to pass)
    //3.
    //Push root frame with answeredYes = -1
    fs_push(&stack, g_root, -1); //answeredYes is last parameter = -1
    //4. 
    Node *parent = NULL;
    int parentAnswer = -1;
    int guessedCorrectly = 0;
    //5.
    //While stack not empty:
    while (!fs_empty(&stack)) {
      //a.
      //Pop current frame
      Frame frame = fs_pop(&stack);
      Node *curr = frame.node;
      //b.
      //If current node is a question:
      if (curr->isQuestion) {
      //Display question and get user's answer (y/n)
        clear();
        mvprintw(2, 2, "%s (y/n): ", curr->text);
        refresh();
        int ch;
        do { ch = getch(); } 
          while (ch != 'y' && ch != 'n');
        //Set parent = current node
        parent = curr;
        //Set parentAnswer = answer
        parentAnswer = (ch == 'y');
        //Push appropriate child (yes or no) onto stack
        if (ch == 'y') {
          fs_push(&stack, curr->yes, 1);
          }
        else {
          fs_push(&stack, curr->no, 0);
        }
      }
      //c.
      //If current node is a leaf (animal):
      else {
        clear();
        //Ask "Is it a [animal]?"
        mvprintw(2, 2, "It is a %s? (y/n): ", curr->text);
        refresh();
        int ch;
        do { ch = getch(); } 
          while (ch != 'y' && ch != 'n');
        //If correct: celebrate and break
        if (ch == 'y') {
          mvprintw(4, 2, "Yay! I guessed it!");
          refresh();
          getch();
          guessedCorrectly = 1;
          break;
          }
        //If wrong: LEARNING PHASE
        echo();
        char correctAnimal[128];
        char newQuestionText[256];
        int newAnswerYes = 0;
        //i. 
        //Get correct animal name from user
        clear();
        mvprintw(2, 2, "I give up. What animal were you thinking of? ");
        getnstr(correctAnimal, sizeof(correctAnimal) - 1);
        //ii. 
        //Get distinguishing question
        mvprintw(4, 2, "Give me a question that distinguishes a %s from a %s: ", correctAnimal, curr->text);
        getnstr(newQuestionText, sizeof(newQuestionText) - 1);
        //iii. 
        //Get answer for new animal (y/n for the question)
        mvprintw(6, 2, "For a %s, what is the answer to that question? (y/n): ", correctAnimal);
        refresh();
        int ans;
        do { ans = getch(); } 
          while (ans != 'y' && ans != 'n');
        newAnswerYes = (ans == 'y');
        noecho();
        //iv. 
        //Create new question node and new animal node
        Node *newAnimal = create_animal_node(correctAnimal);
        Node *newQuestion = create_question_node(newQuestionText);
        //v. 
        //Link them: if newAnswer is yes, newQuestion->yes = newAnimal
        if (newAnswerYes) {
          newQuestion->yes = newAnimal;
          newQuestion->no = curr;
          }
        else {
          newQuestion->no = newAnimal;
          newQuestion->yes = curr;
          }
        //vi. 
        //Update parent pointer (or g_root if parent is NULL)
        if (parent == NULL) {
          g_root = newQuestion;
          }
        else if (parentAnswer == 1) {
          parent->yes = newQuestion;
          }
        else {
          parent->no = newQuestion;
          }
          //vii. 
          //Create Edit record and push to g_undo
        //Save and Use for undo/redo
        Edit edit = {
          .parent = parent,
          .wasYesChild = (parentAnswer == 1),
          .oldLeaf = curr,
          .newLeaf = newAnimal,
          .newQuestion = newQuestion
          };
        
        es_push(&g_undo, edit);
        //viii.
        //Clear g_redo stack
        es_clear(&g_redo);
        //ix. 
        //Update g_index with canonicalized question
        h_put(&g_index, newQuestionText, newQuestion);
        
        mvprintw(8, 2, "Got it! I'll remember that next time!");
        refresh();
        getch();
        guessedCorrectly = 1;
        break;
        }
      }
    
    if (!guessedCorrectly) {
      mvprintw(10, 2, "Couldn't guess anything... maybe the tree is empty?");
      refresh();
      getch();
      }
    
    //6.
    //Free stack
    fs_free(&stack);
}

/* TODO 32: Implement undo_last_edit
 * Undo the most recent tree modification
 * 
 * Steps:
 * 1. Check if g_undo stack is empty, return 0 if so
 * 2. Pop edit from g_undo
 * 3. Restore the tree structure:
 *    - If edit.parent is NULL:
 *      - Set g_root = edit.oldLeaf
 *    - Else if edit.wasYesChild:
 *      - Set edit.parent->yes = edit.oldLeaf
 *    - Else:
 *      - Set edit.parent->no = edit.oldLeaf
 * 4. Push edit to g_redo stack
 * 5. Return 1
 * 
 * Note: We don't free newQuestion/newLeaf because they might be redone
 */
int undo_last_edit() {
    // TODO: Implement this function -- DONE (I think; no test to pass)
    //1.
    //Check if g_undo stack is empty, return 0 if so
    if (es_empty(&g_undo)) {
      return 0;
      }
    
    //2.
    //Pop edit from g_undo
    Edit edit = es_pop(&g_undo);
    
    //3.
    //Restore the tree structure:
    //Follow instructions^^
    if (edit.parent == NULL) {
      g_root = edit.oldLeaf;
      }
    else if (edit.wasYesChild) {
      edit.parent->yes = edit.oldLeaf;
      }
    else {
      edit.parent->no = edit.oldLeaf;
      }
    
    //4.
    //Push edit to g_redo stack
    es_push(&g_redo, edit);
    
    //5.
    //Return 1
    return 1;

}

/* TODO 33: Implement redo_last_edit
 * Redo a previously undone edit
 * 
 * Steps:
 * 1. Check if g_redo stack is empty, return 0 if so
 * 2. Pop edit from g_redo
 * 3. Reapply the tree modification:
 *    - If edit.parent is NULL:
 *      - Set g_root = edit.newQuestion
 *    - Else if edit.wasYesChild:
 *      - Set edit.parent->yes = edit.newQuestion
 *    - Else:
 *      - Set edit.parent->no = edit.newQuestion
 * 4. Push edit back to g_undo stack
 * 5. Return 1
 */
int redo_last_edit() {
    // TODO: Implement this function
    //1.
    //Check if g_redo stack is empty, return 0 if so
    if (es_empty(&g_redo)) {
      return 0;
      }
    
    //2.
    //Pop edit from g_redo
    Edit edit = es_pop(&g_redo);
    
    //3.
    //Reapply the tree modification:
    //Follow instructions^^
    if (edit.parent == NULL) {
      g_root = edit.newQuestion;
      }
    else if (edit.wasYesChild) {
      edit.parent->yes = edit.newQuestion;
      }
    else {
      edit.parent->no = edit.newQuestion;
      }
    
    //4. 
    //Push edit back to g_undo stack
    es_push(&g_undo, edit);
    
    //5. 
    // Return 1
    return 1;
    

}