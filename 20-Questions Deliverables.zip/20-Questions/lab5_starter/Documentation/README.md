# ECE 312 - Lab 5 Write-Up

**Name:** Collin Wallace 
**EID:** cmw5342  
**Date:** 11/7/2025

---

## 1. Design Decisions (3-4 sentences)

Briefly describe your key design choices and rationale: */ Most of my design choices and rationale stemmed from the instructions commented for each todos. /*

- **Data structure implementations:** How did you approach the stack/queue/hash table? Any specific design trade-offs? */ The stacks were designed with a dynamically allocated array, with resizing size and capacity if needed. The queues used a linked list design (give a constant time enqueue/dequeue), and the hash table uses a hash key algorithm given (djb2) while dealing with collisions through chaining (using linked lists) /*

- **Game loop strategy:** How did you structure the iterative traversal? What was your approach to the learning phase? */ My structure to the iterative traversal using a manual stack (FrameStack) where each frame represents a decision point in the binary tree. Starting with pushing the root node onto the stack, and then repeatedly popping the top frame to process the current node. Then, if the node is a question, I ask the user for input (yes/no) and push appropriate child node. If the node is a leaf, I handle the guessing and learning phase. In the learning phase, I prompt the user for correct animal and distinguishing question, then dynamically reconstruct the tree and link new nodes. /*


- **Memory management:** What strategy did you use to avoid leaks? Any particular challenges? */ Inside the data structures, each structure has a function that is reponsible for freeing its own internal data before being released. Then, generally all of my allocations were paired with corresponding free functions. I had challenges keeping track and managing partial allocations and reallocations and making sure to properly free all levels of each data afterwards. /*


---

## 2. Complexity Analysis (3-4 sentences)

Provide Big-O analysis for the following operations. Include brief justification:

- **Game traversal** (from root to leaf): */ The play_game() loop has a Big-O complexity of O(n) where n is the height of the binary tree. The traversal follows a single path from the root to leaf, and at each step the user only inputs one question or pushes one child onto the stack, and since only one frame is processed per question, the time complexity grows linearly with the height of the tree. /*


- **save_tree():** */ The save_tree() time complexity is O(n^2), where n is the number of nodes in the tree. There are two seperate nested for-loops inside of a for-loop, the outer loop is caused by the BFS when assigning IDs, and the inner loops are in the "found" check loops for the yes/no children to check if a node has already been added to mapping, or in find_id, another linear scan. [O(n) * (O(n) + O(n))] = O(n^2) /*


- **Hash table put() in worst case:** */ The put() has a worst-case time complexity of O(n), only when the keys hash to the same bucket, resulting in a linked list traversal (from chaining) and insert to create a new entry. Normally, put() runs O(1). /*


- **undo_last_edit():** */ The undo_last_edit() runs in O(1) time. There are no loops, each operation checks if stack is empty, pops most recent edit, updates tree, and pushes the edit onto the redo stack, leaving a constant time as there is no traversal. /*


---

## 3. Testing & Debugging (2-3 sentences)

Describe your testing process and any major bugs you encountered:

- **Testing approach:** What was your strategy beyond running `make test`? */ Stepping through my code, taking a step back and rethinking my implementation logic to walk through the barebones of my code, and trying different strategies. /*


- **Most difficult bug:** What was the hardest bug to find/fix and how did you solve it? */ In my persist load function, it was difficult to find where and how I should be freeing the nodes, and yes/no ids correctly. I used valgrind to check if I had memory leaks and I was freeing correctly, and I stepped through my code to find where memory was or wasn't being freed.  /*


---

## 4. Implementation Challenges (2-3 sentences)

Which TODOs were most challenging and why?

1. **Hardest TODO:** */ TODO 31 - Play Game (loop): Had complex implementation that involved multiple assignments all coming together in one section of code. I had trouble figuring out what was the best order to sort which tasks to do first that would transition well to gameplay. /*


2. **Most time-consuming:** */ TODO 27 and TODO 28 - Save and Load Tree: These took the most time just because of the sheer size of the pieces of code. I had to take many steps back along the writing process to make sure I was following my train of thought correctly in the code. /*


3. **Most interesting:** */ TODO 32 and 33 - Undo and Redo Edit - For me these were interesting because I use these types of functions all the time in my daily life and it was cool to see how these kinds of functions work behind the scenes. Also to see it work when running the game and being able to just pop back and forth without anything breaking was fun to see the structural strength of the code. /*


---

## 5. Time Spent

Provide approximate hours for each phase:

- Phase 1 (Data Structures): 15-20 hours
- Phase 2 (Game Logic): 10 hours  
- Phase 3 (Persistence): 10 hours
- Testing/Debugging: 5 hours
- **Total:** around 40 hours

---

## 6. Reflection (1-2 sentences)

What was the most valuable lesson from this lab? */ Learning how to interact with a VPN and terminal based coding (along with learning and using new debugging styles and valgrind/fsanitize for memory leaks), and being given the full assignment and learning how to break down a large task into progressive steps (feels more realistic). /*


---

## Submission Checklist

- [ DONE ] All 32 required TODOs implemented
- [ DONE ] `make test` passes with no failures
- [ DONE ] `make valgrind` shows no memory leaks
- [ DONE ] Game fully functional (play, learn, undo, redo, save, load)
- [ DONE ] Code compiles without warnings (`-Wall -Wextra`)
- [ DONE ] This write-up completed
- [ NO ] Optional TODO 30 attempted? (Yes/No): _____
